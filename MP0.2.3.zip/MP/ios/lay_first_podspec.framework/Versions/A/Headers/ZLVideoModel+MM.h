//
//  ZLVideoModel+MM.h
//  lay_first_podspec
//
//  Created by Lay on 2019/6/6.
//

#import "ZLVideoModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface ZLVideoModel (MM)

@end

NS_ASSUME_NONNULL_END
